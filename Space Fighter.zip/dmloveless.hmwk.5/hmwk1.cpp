/*
* Author:	Keith Bush
*			UALR
* 
* Date:		January 26, 2012	
*
* File:		hmwk.1.cpp
*
* Purpose:	The purpose of this homework is to review Programming I/II topics covering
*           file input/output, header/object files, random number generation seeding and
*           usage, as well as linking with the SDL graphics libraries
*/

#include <iostream>
#include <cstdlib> 
#include <ctime> 
#include "GameEngine.h"

using namespace std;

int main(int argc, char *argv[]){

	//Seed random number generator
	srand((unsigned)time(0)); 

	//Construct Engine
	GameEngine engine; 

	return 0;

}